#ifndef _NTIOS_PLATFORM_FD_H_
#define _NTIOS_PLATFORM_FD_H_

#include <linux/limits.h>  // PATH_MAX
#define FLASH_DISK_FILE_NAME "fd"
#define FLASH_DISK_FILE_NAME_SHAD "fd.shd"

#endif  // _NTIOS_PLATFORM_FD_H_