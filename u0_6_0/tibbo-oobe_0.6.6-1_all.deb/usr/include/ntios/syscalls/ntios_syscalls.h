#ifndef __NTIOS_SYSCALLS_H__
#define __NTIOS_SYSCALLS_H__

namespace ntios {
namespace syscalls {

void doevents(); 

} // namespace syscalls
} // namespace ntios


#endif // __NTIOS_SYSCALLS_H__